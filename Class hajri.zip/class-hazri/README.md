# Class Hazri — V1 (Basic Foundation)

QR-based teacher attendance system for the madrasa. Plain HTML/CSS/JS +
Firebase Firestore — no build step, so it copies straight into a GitHub
Codespace or any static host.

## Files

```
class-hazri/
├── index.html        # Check-in page (this is what each classroom QR opens)
├── qr-setup.html      # Generates + prints the 5 colored class QR codes
├── admin.html          # PIN-protected records dashboard
├── logo.svg              # Placeholder logo — replace with the real one
├── css/style.css
└── js/
    ├── firebase-config.js  # <-- EDIT THIS FIRST (Firebase keys, teachers, classes, PIN)
    ├── checkin.js
    ├── qr-generator.js
    └── admin.js
```

## Setup steps

1. **Firebase**: create a project (or reuse your existing one), enable
   Firestore in *test mode* for now, and paste your web app config into
   `js/firebase-config.js`.
2. **Teachers**: replace the 7 placeholder names in `TEACHERS` inside
   `firebase-config.js` with the real names.
3. **Madrasa name/logo**: replace `[Madrasa Ka Naam]` in the three HTML
   files, and swap `logo.svg` for the real logo.
4. **Deploy** (e.g. GitHub Pages from this repo, or any static host).
5. Open `qr-setup.html` on the live site once, and **Print All QR Codes**.
   Post each colored QR in its matching classroom.
6. Share the `admin.html` link with yourself / Walid Sahab. PIN is set
   in `ADMIN_PIN` (default `2026` — change it).

## How it works

- Each class's QR encodes `index.html?class=class-1` (etc.) with that
  class's color baked into `firebase-config.js`.
- Teacher scans with their own phone → opens the check-in page → picks
  their name → taps once to mark **Arrival**, taps again later (same QR)
  to mark **Departure**. Exact time, date, and class are saved to
  Firestore automatically.
- Admin dashboard reads all records and filters by date/class.

## What's intentionally left for later (per the V1 brief)

- Real authentication (Firebase Auth) instead of a shared PIN
- Teacher login / their own history view
- Stronger QR verification (e.g. geofencing, rotating codes)
- Attendance reports/export (CSV, monthly summary)
- Editing/deleting a record from the admin panel
