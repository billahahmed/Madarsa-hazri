import {
  db, TEACHERS, CLASSES,
  collection, addDoc, updateDoc, doc, query, where, getDocs, Timestamp
} from "./firebase-config.js";

const params = new URLSearchParams(window.location.search);
const classId = params.get("class");
const cls = CLASSES.find(c => c.id === classId);

const banner = document.getElementById("banner");
const classNameEl = document.getElementById("className");
const teacherSelect = document.getElementById("teacherSelect");
const actionBtn = document.getElementById("actionBtn");
const statusMsg = document.getElementById("statusMsg");

let currentRecord = null; // existing today's record for the selected teacher, if any
let mode = null; // "checkin" | "checkout" | "done"

function todayStr() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function timeStr() {
  return new Date().toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit", second: "2-digit" });
}

function showStatus(text, ok = true) {
  statusMsg.textContent = text;
  statusMsg.className = "status-msg show " + (ok ? "ok" : "err");
}

// --- Setup: validate class + render banner + populate teachers ---
if (!cls) {
  classNameEl.textContent = "Invalid QR Code";
  banner.style.background = "#7A2C3E";
  actionBtn.textContent = "This QR code is not recognised";
} else {
  banner.style.background = cls.color;
  classNameEl.textContent = cls.name;

  TEACHERS.forEach(t => {
    const opt = document.createElement("option");
    opt.value = t.id;
    opt.textContent = t.name;
    teacherSelect.appendChild(opt);
  });
}

// --- When a teacher is selected, check today's existing record ---
teacherSelect.addEventListener("change", async () => {
  const teacherId = teacherSelect.value;
  statusMsg.className = "status-msg";
  currentRecord = null;

  if (!teacherId || !cls) {
    actionBtn.disabled = true;
    actionBtn.textContent = "Select your name first";
    return;
  }

  actionBtn.disabled = true;
  actionBtn.textContent = "Checking…";

  const q = query(
    collection(db, "attendance"),
    where("teacherId", "==", teacherId),
    where("classId", "==", cls.id),
    where("date", "==", todayStr())
  );
  const snap = await getDocs(q);

  if (snap.empty) {
    mode = "checkin";
    actionBtn.textContent = `Mark Arrival — ${cls.name}`;
    actionBtn.disabled = false;
  } else {
    const docSnap = snap.docs[0];
    currentRecord = { id: docSnap.id, ...docSnap.data() };
    if (!currentRecord.checkOut) {
      mode = "checkout";
      actionBtn.textContent = `Mark Departure — ${cls.name}`;
      actionBtn.disabled = false;
    } else {
      mode = "done";
      actionBtn.textContent = "Already completed for today";
      actionBtn.disabled = true;
      showStatus(
        `Aaj already record ho chuka hai — Arrival ${currentRecord.checkIn}, Departure ${currentRecord.checkOut}`,
        true
      );
    }
  }
});

// --- Button action: write to Firestore ---
actionBtn.addEventListener("click", async () => {
  const teacherId = teacherSelect.value;
  const teacher = TEACHERS.find(t => t.id === teacherId);
  if (!teacher || !cls || !mode || mode === "done") return;

  actionBtn.disabled = true;
  actionBtn.textContent = "Saving…";

  try {
    if (mode === "checkin") {
      await addDoc(collection(db, "attendance"), {
        teacherId: teacher.id,
        teacherName: teacher.name,
        classId: cls.id,
        className: cls.name,
        date: todayStr(),
        checkIn: timeStr(),
        checkOut: null,
        createdAt: Timestamp.now()
      });
      showStatus(`✅ Arrival marked — ${teacher.name}, ${timeStr()}`, true);
      actionBtn.textContent = "Marked ✓";
    } else if (mode === "checkout") {
      await updateDoc(doc(db, "attendance", currentRecord.id), {
        checkOut: timeStr()
      });
      showStatus(`✅ Departure marked — ${teacher.name}, ${timeStr()}`, true);
      actionBtn.textContent = "Marked ✓";
    }
  } catch (err) {
    showStatus("❌ Save nahi hua, dobara try karein. (" + err.message + ")", false);
    actionBtn.disabled = false;
  }
});
