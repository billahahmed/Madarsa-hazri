import {
  db, CLASSES, ADMIN_PIN,
  collection, query, orderBy, getDocs
} from "./firebase-config.js";

const pinGate = document.getElementById("pinGate");
const pinInput = document.getElementById("pinInput");
const pinBtn = document.getElementById("pinBtn");
const pinError = document.getElementById("pinError");
const dashboard = document.getElementById("dashboard");
const dateFilter = document.getElementById("dateFilter");
const classFilter = document.getElementById("classFilter");
const recordsBody = document.getElementById("recordsBody");
const emptyMsg = document.getElementById("emptyMsg");
const summary = document.getElementById("summary");

let allRecords = [];

function classColor(classId) {
  const c = CLASSES.find(c => c.id === classId);
  return c ? c.color : "#888";
}

// --- PIN gate ---
pinBtn.addEventListener("click", () => {
  if (pinInput.value === ADMIN_PIN) {
    pinGate.style.display = "none";
    dashboard.style.display = "block";
    loadRecords();
  } else {
    pinError.textContent = "Galat PIN. Dobara try karein.";
    pinError.classList.add("show");
  }
});
pinInput.addEventListener("keydown", e => { if (e.key === "Enter") pinBtn.click(); });

// --- Populate class filter ---
CLASSES.forEach(c => {
  const opt = document.createElement("option");
  opt.value = c.id;
  opt.textContent = c.name;
  classFilter.appendChild(opt);
});

// --- Load all attendance records ---
async function loadRecords() {
  const q = query(collection(db, "attendance"), orderBy("date", "desc"));
  const snap = await getDocs(q);
  allRecords = snap.docs.map(d => ({ id: d.id, ...d.data() }));
  render();
}

function render() {
  const dateVal = dateFilter.value.trim();
  const classVal = classFilter.value;

  const filtered = allRecords.filter(r => {
    if (dateVal && r.date !== dateVal) return false;
    if (classVal && r.classId !== classVal) return false;
    return true;
  });

  recordsBody.innerHTML = "";
  emptyMsg.style.display = filtered.length === 0 ? "block" : "none";

  filtered.forEach(r => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${r.teacherName}</td>
      <td><span class="badge" style="background:${classColor(r.classId)}">${r.className}</span></td>
      <td>${r.date}</td>
      <td>${r.checkIn || "—"}</td>
      <td>${r.checkOut || "—"}</td>
    `;
    recordsBody.appendChild(tr);
  });

  summary.textContent = `${filtered.length} record(s)`;
}

dateFilter.addEventListener("input", render);
classFilter.addEventListener("change", render);
