// ============================================================
// Class Hazri — Configuration
// Edit the values below to match your madrasa's setup.
// ============================================================

// --- 1. Firebase project settings -----------------------------------
// Get these from: Firebase Console -> Project Settings -> Your apps -> Web app
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT_ID.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID"
};

// --- 2. Teachers (7) --------------------------------------------------
// id must be unique and stable — do not change an id once attendance
// records exist for that teacher, or past records will look "orphaned".
const TEACHERS = [
  { id: "t1", name: "Teacher 1" },
  { id: "t2", name: "Teacher 2" },
  { id: "t3", name: "Teacher 3" },
  { id: "t4", name: "Teacher 4" },
  { id: "t5", name: "Teacher 5" },
  { id: "t6", name: "Teacher 6" },
  { id: "t7", name: "Teacher 7" }
];

// --- 3. Classes (5) — each with its own colour ------------------------
const CLASSES = [
  { id: "class-1", name: "Class 1", color: "#14532D" }, // emerald
  { id: "class-2", name: "Class 2", color: "#23395B" }, // indigo
  { id: "class-3", name: "Class 3", color: "#7A2C3E" }, // maroon
  { id: "class-4", name: "Class 4", color: "#B8860B" }, // brass / ochre
  { id: "class-5", name: "Class 5", color: "#0E7C7B" }  // teal
];

// --- 4. School day window (for reference / future validation) --------
const SCHOOL_START = "08:00";
const SCHOOL_END = "16:00";

// --- 5. Admin access ----------------------------------------------------
// Simple PIN for V1. Replace with real auth later (see README "Future").
const ADMIN_PIN = "2026";

// --- 6. Firebase init (Firestore only, via CDN modular SDK) ----------
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import {
  getFirestore, collection, addDoc, updateDoc, doc,
  query, where, getDocs, orderBy, Timestamp
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

export {
  db, TEACHERS, CLASSES, SCHOOL_START, SCHOOL_END, ADMIN_PIN,
  collection, addDoc, updateDoc, doc, query, where, getDocs, orderBy, Timestamp
};
