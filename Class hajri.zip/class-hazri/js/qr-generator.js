import { CLASSES } from "./firebase-config.js";

// Update this once your site is deployed (e.g. GitHub Pages / your domain).
const BASE_URL = window.location.origin + window.location.pathname.replace("qr-setup.html", "index.html");

const grid = document.getElementById("qrGrid");

CLASSES.forEach(cls => {
  const url = `${BASE_URL}?class=${cls.id}`;

  const card = document.createElement("div");
  card.className = "qr-card";
  card.style.background = cls.color;
  card.innerHTML = `
    <div class="qr-name">${cls.name}</div>
    <canvas id="qr-${cls.id}"></canvas>
    <div style="font-size:0.72rem;opacity:0.85;">${url}</div>
  `;
  grid.appendChild(card);

  // eslint-disable-next-line no-undef
  QRCode.toCanvas(document.getElementById(`qr-${cls.id}`), url, { width: 160, margin: 1 }, err => {
    if (err) console.error(err);
  });
});
